package com.example.demo.utils;

public class ConstanResponses {

    public static final String RESPONSE_CORRECT_GET_USERS_ADMIN  = "User list retrieved successfully";
    public static final String RESPONSE_INCORRECT_GET_USERS_ADMIN  = "User list retrieved successfully";

}
