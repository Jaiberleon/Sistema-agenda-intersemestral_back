package com.example.demo.dto.interfazdto;

public interface IFacultyDto {

     Long getFacultyId();
     String getName();
}
