package com.example.demo.dto.interfazdto;

public interface IProgramaDto {

    Long getId();
    String getName();
}
